"""Core application logic."""
